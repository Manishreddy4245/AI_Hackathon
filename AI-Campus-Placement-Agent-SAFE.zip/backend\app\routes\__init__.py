"""
PlaceMind API Routes Package
"""
