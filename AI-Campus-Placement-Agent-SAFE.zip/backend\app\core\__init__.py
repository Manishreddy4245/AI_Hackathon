"""
PlaceMind Core Package
"""
