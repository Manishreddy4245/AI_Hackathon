"""
PlaceMind Pydantic Schemas Package
"""
