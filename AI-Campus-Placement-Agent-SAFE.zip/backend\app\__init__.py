"""
PlaceMind Backend Application Package
"""
